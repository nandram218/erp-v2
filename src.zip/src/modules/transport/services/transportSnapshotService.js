export const createTransportSnapshot = (
    data
) => {
    return {
        snapshotId: `TS-${Date.now()}`,

        routeId: data.routeId || data.id,

        routeName:
            data.routeName || "",

        vehicleNumber:
            data.vehicleNumber || "",

        driverName:
            data.driverName || "",

        pickupPoints:
            data.pickupPoints || [],

        monthlyFee: Number(
            data.monthlyFee || 0
        ),

        generatedAt:
            new Date().toISOString(),
    };
};