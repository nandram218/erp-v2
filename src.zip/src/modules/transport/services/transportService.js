import {
    createTransportSnapshot,
} from "./transportSnapshotService";

const ERP_DB_KEY = "ERP_DB";

const getERPDB = () => {
    try {
        return (
            JSON.parse(
                localStorage.getItem(ERP_DB_KEY)
            ) || {}
        );
    } catch {
        return {};
    }
};

const saveERPDB = (db) => {
    localStorage.setItem(
        ERP_DB_KEY,
        JSON.stringify(db)
    );
};

const generateRouteId = (
    routes = []
) => {
    if (!routes.length) {
        return 1;
    }

    return (
        Math.max(
            ...routes.map((r) =>
                Number(r.id || 0)
            )
        ) + 1
    );
};

export const getTransportRoutes = () => {
    const db = getERPDB();

    return db.transportRoutes || [];
};

export const getVehicles = () => {
    const db = getERPDB();

    return db.transportVehicles || [];
};

export const getDrivers = () => {
    const db = getERPDB();

    return db.transportDrivers || [];
};

export const getPickupPoints = () => {
    const db = getERPDB();

    return (
        db.transportPickupPoints || []
    );
};

export const createTransportRoute = (
    payload
) => {
    const db = getERPDB();

    const routes =
        db.transportRoutes || [];

    const routeId =
        payload.id ||
        generateRouteId(routes);

    const record = {
        id: routeId,

        routeName:
            payload.routeName || "",

        vehicleNumber:
            payload.vehicleNumber || "",

        vehicleType:
            payload.vehicleType || "Bus",

        driverName:
            payload.driverName || "",

        driverPhone:
            payload.driverPhone || "",

        monthlyFee: Number(
            payload.monthlyFee || 0
        ),

        pickupPoints:
            payload.pickupPoints || [],

        gpsEnabled:
            payload.gpsEnabled || false,

        liveTrackingEnabled:
            payload.liveTrackingEnabled ||
            false,

        active:
            payload.active !== undefined
                ? payload.active
                : true,

        createdAt:
            payload.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString(),
    };

    const snapshot =
        createTransportSnapshot(
            record
        );

    const exists = routes.some(
        (r) =>
            Number(r.id) ===
            Number(routeId)
    );

    let updatedRoutes = [];

    if (exists) {
        updatedRoutes = routes.map(
            (route) =>
                Number(route.id) ===
                    Number(routeId)
                    ? {
                        ...record,
                        snapshot,
                    }
                    : route
        );
    } else {
        updatedRoutes = [
            ...routes,
            {
                ...record,
                snapshot,
            },
        ];
    }

    const updatedDB = {
        ...db,

        transportRoutes:
            updatedRoutes,

        transportSnapshots: [
            ...(db.transportSnapshots ||
                []),

            snapshot,
        ],
    };

    saveERPDB(updatedDB);

    return record;
};

export const removeTransportRoute = (
    id
) => {
    const db = getERPDB();

    const routes =
        db.transportRoutes || [];

    const updatedRoutes =
        routes.filter(
            (route) =>
                Number(route.id) !==
                Number(id)
        );

    saveERPDB({
        ...db,

        transportRoutes:
            updatedRoutes,
    });
};

export const toggleRouteStatus = (
    id
) => {
    const db = getERPDB();

    const routes =
        db.transportRoutes || [];

    const updatedRoutes =
        routes.map((route) => {
            if (
                Number(route.id) ===
                Number(id)
            ) {
                return {
                    ...route,

                    active:
                        !route.active,

                    updatedAt:
                        new Date().toISOString(),
                };
            }

            return route;
        });

    saveERPDB({
        ...db,

        transportRoutes:
            updatedRoutes,
    });
};

export const calculateTransportFee = (
    routeId
) => {
    const routes =
        getTransportRoutes();

    const route = routes.find(
        (r) =>
            Number(r.id) ===
            Number(routeId)
    );

    return Number(
        route?.monthlyFee || 0
    );
};

export const assignStudentTransport = (
    student
) => {
    if (!student.transportRouteId) {
        return null;
    }

    const routes =
        getTransportRoutes();

    const route = routes.find(
        (r) =>
            Number(r.id) ===
            Number(
                student.transportRouteId
            )
    );

    if (!route) {
        return null;
    }

    return {
        routeId: route.id,

        routeName:
            route.routeName,

        pickupPoint:
            student.pickupPoint || "",

        vehicleNumber:
            route.vehicleNumber,

        monthlyFee:
            route.monthlyFee,

        assignedAt:
            new Date().toISOString(),
    };
};

export const calculateRouteOccupancy =
    (routeId) => {
        const db = getERPDB();

        const students =
            db.students || [];

        return students.filter(
            (student) =>
                Number(
                    student.transport
                        ?.routeId
                ) === Number(routeId)
        ).length;
    };

export const generateTransportSnapshot =
    (transport) => {
        return createTransportSnapshot(
            transport
        );
    };

export const getTransportDashboard =
    () => {
        const routes =
            getTransportRoutes();

        const db = getERPDB();

        const students =
            db.students || [];

        const activeRoutes =
            routes.filter(
                (r) => r.active
            ).length;

        const revenue =
            routes.reduce(
                (sum, route) =>
                    sum +
                    Number(
                        route.monthlyFee ||
                        0
                    ),
                0
            );

        return {
            totalRoutes:
                routes.length,

            activeVehicles:
                activeRoutes,

            totalStudents:
                students.filter(
                    (s) =>
                        s.transport
                ).length,

            monthlyRevenue:
                revenue,
        };
    };