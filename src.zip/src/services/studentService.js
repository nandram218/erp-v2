// src/services/studentService.js
// Student business logic — persistence via schoolStore → storageService (ERP_DB)

import { useSchoolStore } from "../store/schoolStore";

/** Match by studentId (canonical) or legacy numeric id */
const matchesStudent = (student, identifier) => {
    if (identifier === undefined || identifier === null || identifier === "") {
        return false;
    }

    const key = String(identifier);

    if (student.studentId != null && String(student.studentId) === key) {
        return true;
    }

    if (student.id != null && String(student.id) === key) {
        return true;
    }

    return false;
};

/* =========================================================
   GLOBAL STUDENT ENGINE
========================================================= */

/* =========================================================
   GET STUDENTS
========================================================= */

export const getStudents = () => {
    return useSchoolStore.getState().students || [];
};

/* =========================================================
   GENERATE STUDENT ID
========================================================= */

export const generateStudentId = () => {

    const state =
        useSchoolStore.getState();

    const schoolData =
        state.schoolData || {};

    const schoolId =
        schoolData.schoolId ||
        "SCH-DEMO";

    const sessionId =
        schoolData.sessionId ||
        "2025-26";

    const students =
        state.students || [];

    const nextNumber =
        String(students.length + 1)
            .padStart(6, "0");

    return `${schoolId}-${sessionId}-STU-${nextNumber}`;
};

/* =========================================================
   ADD STUDENT
========================================================= */

export const addStudent = (
    student = {}
) => {

    const {
        students,
        setStudents,
        schoolData
    } = useSchoolStore.getState();

    const studentId =
        generateStudentId();

    const finalStudent = {

        ...student,

        /* =================
           PRIMARY IDENTITY
        ================= */

        studentId,

        /* =================
           GLOBAL CONTEXT
        ================= */

        schoolId:
            schoolData.schoolId || "",

        branchId:
            schoolData.branchId || "",

        sessionId:
            schoolData.sessionId || "",

        /* =================
           TIMESTAMPS
        ================= */

        createdAt:
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString(),
    };

    const updatedStudents = [
        ...students,
        finalStudent
    ];

    setStudents(updatedStudents);

    return finalStudent;
};

/* =========================================================
   UPDATE STUDENT
========================================================= */

export const updateStudent = (
    identifier,
    updatedData = {}
) => {

    const {
        students,
        setStudents
    } = useSchoolStore.getState();

    const updatedStudents =
        students.map((student) =>

            matchesStudent(student, identifier)

                ? {
                    ...student,
                    ...updatedData,

                    /* =================
                       NEVER OVERRIDE
                    ================= */

                    studentId:
                        student.studentId,

                    schoolId:
                        student.schoolId,

                    branchId:
                        student.branchId,

                    sessionId:
                        student.sessionId,

                    updatedAt:
                        new Date().toISOString(),
                }

                : student
        );

    setStudents(updatedStudents);

    return updatedStudents.find((student) =>
        matchesStudent(student, identifier)
    );
};

/* =========================================================
   DELETE STUDENT
========================================================= */

export const deleteStudent = (
    identifier
) => {

    const {
        students,
        setStudents
    } = useSchoolStore.getState();

    const updatedStudents =
        students.filter(
            (student) => !matchesStudent(student, identifier)
        );

    setStudents(updatedStudents);

    return true;
};

/* =========================================================
   GET SINGLE STUDENT
========================================================= */

export const getStudentById = (
    identifier
) => {

    const students =
        useSchoolStore
            .getState()
            .students || [];

    return students.find((student) =>
        matchesStudent(student, identifier)
    );
};

/* =========================================================
   CHECK DUPLICATE STUDENT
========================================================= */

export const studentExists = (
    studentId
) => {

    return !!getStudentById(
        studentId
    );
};
