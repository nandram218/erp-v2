import { useSchoolStore } from "../store/schoolStore";
import {
    calculateFinalFees,
    generateFeeSnapshot,
    generateBillingPreview,
} from "./feeEngine";

const DB_KEY = "ERP_DB";

export const feesService = {

    // ================= GET FULL DB =================

    getDB: () => {
        return JSON.parse(
            localStorage.getItem(DB_KEY) || "{}"
        );
    },

    // ================= SAVE FULL DB =================

    saveDB: (db) => {
        localStorage.setItem(
            DB_KEY,
            JSON.stringify(db)
        );
    },

    // ================= GET FEES =================

    get: () => {
        const db = feesService.getDB();
        return db.fees || {};
    },

    // ================= SAVE FEES =================

    save: (feesData) => {

        const db = feesService.getDB();

        db.fees = feesData;

        feesService.saveDB(db);
    },

    // ================= HISTORY =================

    getHistory: () => {

        const db = feesService.getDB();

        return db.feesHistory || [];
    },

    saveHistory: (history) => {

        const db = feesService.getDB();

        db.feesHistory = history;

        feesService.saveDB(db);
    },

    // ================= RESET =================

    reset: () => {

        const db = feesService.getDB();

        db.fees = {};
        db.feesHistory = [];

        feesService.saveDB(db);
    }
};

// ======================================================
// GLOBAL STUDENT ENGINE
// ======================================================

// ✅ GET STUDENTS

export const getStudents = () => {
    return useSchoolStore.getState().students || [];
};

// ======================================================
// GLOBAL STUDENT ID GENERATOR
// FORMAT:
// SCH-IND-0001-2025-26-STU-000001
// ======================================================

export const generateStudentId = () => {

    const state = useSchoolStore.getState();

    const schoolData = state.schoolData || {};

    const schoolId =
        schoolData.schoolId || "SCH-IND-0001";

    const sessionId =
        schoolData.sessionId || "2025-26";

    const students = state.students || [];

    const nextNumber =
        String(students.length + 1)
            .padStart(6, "0");

    return `${schoolId}-${sessionId}-STU-${nextNumber}`;
};

// ======================================================
// ADD STUDENT
// ======================================================

export const addStudent = (student) => {

    const {
        students,
        setStudents,
        schoolData
    } = useSchoolStore.getState();

    const studentId =
        generateStudentId();

    const finalStudent = {

        ...student,

        // OLD LOCAL ID
        id: Date.now(),

        // GLOBAL IDs
        studentId,

        schoolId:
            schoolData.schoolId,

        branchId:
            schoolData.branchId,

        sessionId:
            schoolData.sessionId,

        createdAt:
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()
    };

    const updated = [
        ...students,
        finalStudent
    ];

    setStudents(updated);

    return finalStudent;
};

// ======================================================
// UPDATE STUDENT
// ======================================================

export const updateStudent = (
    id,
    updatedData
) => {

    const {
        students,
        setStudents
    } = useSchoolStore.getState();

    const updated = students.map((s) =>

        s.id === id

            ? {
                ...s,
                ...updatedData,

                updatedAt:
                    new Date().toISOString()
            }

            : s
    );

    setStudents(updated);
};

// ======================================================
// DELETE STUDENT
// ======================================================

export const deleteStudent = (id) => {

    const {
        students,
        setStudents
    } = useSchoolStore.getState();

    const updated =
        students.filter(
            (s) => s.id !== id
        );

    setStudents(updated);
};