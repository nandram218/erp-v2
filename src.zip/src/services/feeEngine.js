const roundAmount = (amount) => {
    return Number(
        Number(amount || 0).toFixed(2)
    );
};

export const calculateConcessions = (
    payload = {}
) => {
    const {
        concessionAmount = 0,
        scholarshipAmount = 0,
        discountAmount = 0,
    } = payload;

    return roundAmount(
        Number(concessionAmount) +
        Number(scholarshipAmount) +
        Number(discountAmount)
    );
};

export const mergeTransportFees = (
    transport = null
) => {
    if (!transport) {
        return {
            transportFee: 0,
        };
    }

    return {
        transportFee: roundAmount(
            transport.monthlyFee || 0
        ),
    };
};

export const mergeHostelFees = (
    hostel = null
) => {
    if (!hostel) {
        return {
            hostelFee: 0,
        };
    }

    return {
        hostelFee: roundAmount(
            hostel.monthlyFee || 0
        ),
    };
};

export const calculateFinalFees = ({
    student = {},
    transport = null,
    hostel = null,
}) => {
    const baseFee = roundAmount(
        student.baseFee || 0
    );

    const admissionFee = roundAmount(
        student.admissionFee || 0
    );

    const annualFee = roundAmount(
        student.annualFee || 0
    );

    const lateFee = roundAmount(
        student.lateFee || 0
    );

    const transportData =
        mergeTransportFees(
            transport
        );

    const hostelData =
        mergeHostelFees(hostel);

    const concessions =
        calculateConcessions(
            student
        );

    const grossAmount =
        baseFee +
        admissionFee +
        annualFee +
        lateFee +
        transportData.transportFee +
        hostelData.hostelFee;

    const finalAmount =
        grossAmount - concessions;

    return {
        baseFee,

        admissionFee,

        annualFee,

        lateFee,

        transportFee:
            transportData.transportFee,

        hostelFee:
            hostelData.hostelFee,

        concessions,

        grossAmount:
            roundAmount(grossAmount),

        finalAmount:
            roundAmount(finalAmount),

        calculatedAt:
            new Date().toISOString(),
    };
};

export const generateFeeSnapshot = (
    feeData
) => {
    return {
        snapshotId: `FS-${Date.now()}`,

        ...feeData,

        generatedAt:
            new Date().toISOString(),
    };
};

export const generateBillingPreview =
    (feeData) => {
        return {
            payableAmount:
                feeData.finalAmount,

            monthlyEstimate:
                roundAmount(
                    feeData.finalAmount /
                    12
                ),

            quarterlyEstimate:
                roundAmount(
                    feeData.finalAmount /
                    4
                ),

            generatedAt:
                new Date().toISOString(),
        };
    }; 