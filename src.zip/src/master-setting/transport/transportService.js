const KEY = "ERP_TRANSPORT_MASTER";

/* =========================================
   HELPERS
========================================= */

const uid = () =>
    Date.now() +
    Math.floor(Math.random() * 1000);

const safeArray = (v) =>
    Array.isArray(v) ? v : [];

/* =========================================
   DEFAULT STRUCTURE
========================================= */

const defaultDB = {
    routes: [],
    vehicles: [],
    drivers: [],
    mappings: [],
    settings: {
        transportEnabled: true,
        attendanceTracking: false,
        gpsTracking: false,
        smsAlerts: false,
    },
};

/* =========================================
   MAIN SERVICE
========================================= */

export const transportService = {

    /* =========================
       GET FULL DB
    ========================= */

    get: () => {

        try {

            const raw =
                JSON.parse(
                    localStorage.getItem(KEY)
                );

            if (!raw) {
                return defaultDB;
            }

            return {
                routes:
                    safeArray(raw.routes),

                vehicles:
                    safeArray(raw.vehicles),

                drivers:
                    safeArray(raw.drivers),

                mappings:
                    safeArray(raw.mappings),

                settings:
                    raw.settings ||
                    defaultDB.settings,
            };

        } catch {

            return defaultDB;
        }
    },

    /* =========================
       SAVE FULL DB
    ========================= */

    save: (data) => {

        localStorage.setItem(
            KEY,
            JSON.stringify(data)
        );
    },

    /* =========================
       RESET
    ========================= */

    reset: () => {
        localStorage.removeItem(KEY);
    },

    /* =========================
       ROUTE HELPERS
    ========================= */

    getRoutes: () =>
        transportService.get().routes,

    getRouteById: (routeId) => {

        return transportService
            .get()
            .routes
            .find(
                (r) =>
                    String(r.id) ===
                    String(routeId)
            );
    },

    getPointById: (
        routeId,
        pointId
    ) => {

        const route =
            transportService
                .getRouteById(routeId);

        if (!route) return null;

        return (
            route.points || []
        ).find(
            (p) =>
                String(p.id) ===
                String(pointId)
        );
    },

    /* =========================
       CREATE ROUTE
    ========================= */

    createRoute: ({
        routeNo,
        routeName,
        fareType,
        fixedFare,
        points = [],
    }) => {

        const db =
            transportService.get();

        const exists =
            db.routes.find(
                (r) =>
                    r.routeNo === routeNo
            );

        if (exists) {
            throw new Error(
                "Duplicate Route"
            );
        }

        const route = {

            id: uid(),

            routeNo,

            routeName,

            fareType:
                fareType || "fixed",

            fixedFare:
                Number(
                    fixedFare || 0
                ),

            points:
                points.map((p) => ({

                    id: uid(),

                    pointName:
                        p.name || "",

                    fee:
                        Number(
                            p.fare || 0
                        ),

                    pickupTime:
                        p.pickup || "",

                    dropTime:
                        p.drop || "",
                })),

            createdAt:
                new Date().toISOString(),

            updatedAt:
                new Date().toISOString(),
        };

        db.routes.push(route);

        transportService.save(db);

        return route;
    },
};