import { Routes, Route } from "react-router-dom";
import DashboardLayout from "../layouts/DashboardLayout";

// DASHBOARD
import DashboardPage from "../modules/dashboard/pages/DashboardPage";
// STUDENTS MODULE (FULL SAFE STRUCTURE)
import StudentPage from "../modules/students/pages/StudentPage";
import StudentListPage from "../modules/students/pages/StudentListPage";
import StudentForm from "../modules/students/StudentForm";
import StudentIDCards from "../modules/students/pages/StudentIDCards";
import StudentProfile from "../modules/students/pages/StudentProfile";

// FEES
import FeesPage from "../modules/fees/pages/FeesPage";
import FeesHistoryPage from "../modules/fees/pages/FeesHistoryPage";
import DueReportPage from "../modules/fees/pages/DueReportPage";
import PrintReceipt from "../modules/fees/pages/PrintReceipt";
// STAFF
import StaffPage from "../modules/staff/pages/StaffPage";

// CERTIFICATES
import CertificateSelector from "../modules/students/certificates/CertificateSelector";
import CertificatePreview from "../modules/students/certificates/CertificatePreview";
// 🔥 MASTER SETTING IMPORTS
import MasterSettingDashboard from "../master-setting/MasterSettingDashboard";

import SchoolProfile from "../master-setting/school-profile/SchoolProfile";

import AcademicSettings from "../master-setting/academic/AcademicSettings";

import ClassManager from "../master-setting/classes-subjects/ClassManager";
import SubjectManager from "../master-setting/classes-subjects/SubjectManager";

import FeeSettings from "../master-setting/fees/FeeSettings";
import FeeStructure from "../master-setting/fees/FeeStructure";

import ExamSetup from "../master-setting/exams/ExamSetup";
import ExamSchedule from "../master-setting/exams/ExamSchedule";

import TransportSettings from "../master-setting/transport/TransportSettings";
import TransportRoutes from "../master-setting/transport/TransportRoutes";

import HostelSetup from "../master-setting/hostel/HostelSetup";

import RoleManager from "../master-setting/security/RoleManager";
import AccessControl from "../master-setting/security/AccessControl";
import TransportPage from "../modules/transport/pages/TransportPage";
export default function AppRoutes() {
    return (
        <DashboardLayout>
            <Routes>

                {/* DASHBOARD */}
                <Route path="/" element={<DashboardPage />} />
                <Route path="/dashboard" element={<DashboardPage />} />

                {/* ================= STUDENTS MODULE ================= */}

                {/* STUDENTS MODULE FIXED FLOW */}

/* MODULE HUB (BUTTON PAGE) */
                <Route path="/students" element={<StudentPage />} />
/* LIST PAGE (TABLE) */
                <Route path="/students/list" element={<StudentListPage />} />

/* ADD */
                <Route path="/students/add" element={<StudentForm />} />

/* ID CARDS */
                <Route path="/students/idcards" element={<StudentIDCards />} />

/* PROFILE */
                <Route path="/students/view/:id" element={<StudentProfile />} />
                {/* CERTIFICATES */}
                <Route path="/certificate-selector" element={<CertificateSelector />} />
                <Route path="/certificate" element={<CertificatePreview />} />
                {/* ===================================================== */}

                {/* FEES */}
                <Route path="/fees" element={<FeesPage />} />
                <Route path="/fees/history" element={<FeesHistoryPage />} />
                <Route path="/fees/due-report" element={<DueReportPage />} />
                <Route path="/fees/receipt/:id" element={<PrintReceipt />} />
                {/* STAFF */}
                <Route path="/staff" element={<StaffPage />} />
                {/* 🔥 MASTER SETTING */}
                <Route path="/master-setting" element={<MasterSettingDashboard />} />

                <Route path="/master-setting/school-profile" element={<SchoolProfile />} />

                <Route path="/master-setting/academic" element={<AcademicSettings />} />

                <Route path="/master-setting/classes-subjects/classes" element={<ClassManager />} />
                <Route path="/master-setting/classes-subjects/subjects" element={<SubjectManager />} />

                <Route path="/master-setting/fees" element={<FeeSettings />} />
                <Route path="/master-setting/fees/structure" element={<FeeStructure />} />

                <Route path="/master-setting/exams" element={<ExamSetup />} />
                <Route path="/master-setting/exams/schedule" element={<ExamSchedule />} />

                <Route path="/master-setting/transport" element={<TransportSettings />} />
                <Route path="/master-setting/transport/routes" element={<TransportRoutes />} />

                <Route path="/master-setting/hostel" element={<HostelSetup />} />

                <Route path="/master-setting/security" element={<RoleManager />} />
                <Route path="/master-setting/security/access" element={<AccessControl />} />
                <Route
                    path="/transport"
                    element={<TransportPage />}
                />
            </Routes>
        </DashboardLayout>
    );
}